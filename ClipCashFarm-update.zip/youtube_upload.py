"""
YouTube-Uploader (Schritt 4)

Laedt fertige Shorts aus clips/fertig/ auf deinen YouTube-Kanal.
Pro Aufruf wird nur eine kleine Anzahl hochgeladen (Einstellung "youtube_pro_lauf"),
damit die Videos ueber den Tag verteilt erscheinen.

Beim ersten Start oeffnet sich der Browser: mit deinem YouTube-Google-Konto anmelden
und den Zugriff erlauben. Danach merkt sich das Skript die Anmeldung (token.json).

Aufruf:
  python youtube_upload.py            -> naechste(s) Video(s) hochladen
  python youtube_upload.py anmelden   -> nur anmelden/testen
"""

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from googleapiclient.http import MediaFileUpload

# Emojis in Clip-Titeln sollen das Skript nicht abstuerzen lassen (Windows-Konsole/Log-Datei)
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


ORDNER = Path(__file__).resolve().parent
CONFIG_DATEI = ORDNER / "config.json"
CLIENT_SECRET = ORDNER / "client_secret.json"
TOKEN_DATEI = ORDNER / "token.json"
FERTIG_ORDNER = ORDNER / "clips" / "fertig"
LOG_DATEI = ORDNER / "daten" / "youtube_hochgeladen.json"

SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]

STANDARD = {
    "youtube_pro_lauf": 1,            # Videos pro Aufruf
    "youtube_sichtbarkeit": "public", # public, unlisted oder private
    "youtube_kategorie": "20",        # 20 = Gaming
    "youtube_max_alter_tage": 3,      # aeltere Clips nicht mehr hochladen
    "youtube_titel_hashtags": 4,      # so viele Hashtags kommen in den Titel (passend zu 100 Zeichen)
}


def titel_mit_hashtags(info, max_hashtags=4, max_laenge=100):
    """Haengt so viele Hashtags an den Titel, wie in YouTubes 100 Zeichen passen."""
    titel = info["titel"].strip()
    for tag in info.get("tags", [])[:max_hashtags]:
        neu = f"{titel} #{tag}"
        if len(neu) > max_laenge:
            break
        titel = neu
    return titel[:max_laenge]


def lade_json(pfad, standard):
    if pfad.exists():
        return json.loads(pfad.read_text(encoding="utf-8"))
    return standard


def speichere_json(pfad, daten):
    pfad.parent.mkdir(parents=True, exist_ok=True)
    pfad.write_text(json.dumps(daten, indent=2, ensure_ascii=False), encoding="utf-8")


def anmelden():
    cred = None
    if TOKEN_DATEI.exists():
        cred = Credentials.from_authorized_user_file(str(TOKEN_DATEI), SCOPES)
    if cred and cred.valid:
        return cred
    if cred and cred.expired and cred.refresh_token:
        try:
            cred.refresh(Request())
            TOKEN_DATEI.write_text(cred.to_json(), encoding="utf-8")
            return cred
        except Exception as fehler:
            print(f"Anmeldung abgelaufen ({fehler}), bitte neu anmelden.")
    if not CLIENT_SECRET.exists():
        sys.exit("client_secret.json fehlt. Benenne die Google-Datei (client_secret_....json) in client_secret.json um.")
    flow = InstalledAppFlow.from_client_secrets_file(str(CLIENT_SECRET), SCOPES)
    cred = flow.run_local_server(port=0, prompt="consent")
    TOKEN_DATEI.write_text(cred.to_json(), encoding="utf-8")
    return cred


def naechste_videos(cfg, log):
    """Noch nicht hochgeladene Videos, die besten (meiste Twitch-Aufrufe) zuerst."""
    jetzt = datetime.now().timestamp()
    kandidaten = []
    for info_datei in FERTIG_ORDNER.glob("*.json"):
        name = info_datei.stem
        video = FERTIG_ORDNER / f"{name}.mp4"
        if name in log or not video.exists():
            continue
        alter_tage = (jetzt - video.stat().st_mtime) / 86400
        if alter_tage > cfg["youtube_max_alter_tage"]:
            continue
        info = json.loads(info_datei.read_text(encoding="utf-8"))
        kandidaten.append((info.get("twitch_aufrufe", 0), name, video, info))
    kandidaten.sort(reverse=True)
    return kandidaten[: cfg["youtube_pro_lauf"]]


def hochladen(youtube, video, info, cfg):
    body = {
        "snippet": {
            "title": titel_mit_hashtags(info, cfg["youtube_titel_hashtags"]),
            "description": info["beschreibung"][:4900],
            "tags": info.get("tags", [])[:15],
            "categoryId": cfg["youtube_kategorie"],
            "defaultLanguage": "de",
            "defaultAudioLanguage": "de",
        },
        "status": {
            "privacyStatus": cfg["youtube_sichtbarkeit"],
            "selfDeclaredMadeForKids": False,
        },
    }
    media = MediaFileUpload(str(video), mimetype="video/mp4", chunksize=-1, resumable=True)
    anfrage = youtube.videos().insert(part="snippet,status", body=body, media_body=media)
    antwort = None
    while antwort is None:
        _, antwort = anfrage.next_chunk()
    return antwort["id"]


def main():
    cfg = dict(STANDARD)
    cfg.update({k: v for k, v in lade_json(CONFIG_DATEI, {}).items() if k.startswith("youtube_")})

    cred = anmelden()
    youtube = build("youtube", "v3", credentials=cred)
    if len(sys.argv) > 1 and sys.argv[1] == "anmelden":
        print("Anmeldung klappt.")
        return

    log = lade_json(LOG_DATEI, {})
    videos = naechste_videos(cfg, log)
    if not videos:
        print("Keine neuen Videos in clips/fertig/.")
        return

    for aufrufe, name, video, info in videos:
        print(f"Lade hoch: {titel_mit_hashtags(info, cfg['youtube_titel_hashtags'])}")
        try:
            video_id = hochladen(youtube, video, info, cfg)
        except HttpError as fehler:
            text = str(fehler)
            if "quota" in text.lower() or "uploadLimitExceeded" in text:
                print("YouTube-Tageslimit erreicht. Morgen geht es weiter.")
                return
            print(f"  FEHLER: {text[:500]}")
            continue
        log[name] = {
            "youtube_id": video_id,
            "link": f"https://youtube.com/shorts/{video_id}",
            "hochgeladen": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "twitch_aufrufe": aufrufe,
        }
        speichere_json(LOG_DATEI, log)
        print(f"  OK: https://youtube.com/shorts/{video_id}")


if __name__ == "__main__":
    main()
