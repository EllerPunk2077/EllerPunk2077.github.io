"""
Zeigt, welche Clips als Naechstes automatisch hochgeladen werden.

Aufruf: python warteschlange.py
"""

import json
import sys
import time
from datetime import datetime
from pathlib import Path

# Emojis in Clip-Titeln sollen das Skript nicht abstuerzen lassen (Windows-Konsole/Log-Datei)
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


ORDNER = Path(__file__).resolve().parent
FERTIG_ORDNER = ORDNER / "clips" / "fertig"
DATEN = ORDNER / "daten"

PLATTFORMEN = [
    # Name, Log-Datei, Config-Praefix, Upload-Stunden
    ("YouTube", "youtube_hochgeladen.json", "youtube", [12, 14, 16, 18, 20, 22]),
    ("Instagram", "instagram_hochgeladen.json", "instagram", [13, 15, 17, 19, 21]),
    ("TikTok", "tiktok_hochgeladen.json", "tiktok", []),
]


def lade_json(pfad, standard):
    if pfad.exists():
        return json.loads(pfad.read_text(encoding="utf-8"))
    return standard


def naechste_zeiten(stunden, anzahl):
    jetzt = datetime.now()
    zeiten, tag = [], 0
    while len(zeiten) < anzahl and stunden:
        for h in stunden:
            t = jetzt.replace(hour=h, minute=0, second=0, microsecond=0)
            t = t.fromtimestamp(t.timestamp() + tag * 86400)
            if t > jetzt:
                zeiten.append(t)
                if len(zeiten) == anzahl:
                    break
        tag += 1
    return zeiten


def main():
    cfg = lade_json(ORDNER / "config.json", {})
    clips = []
    for info_datei in FERTIG_ORDNER.glob("*.json"):
        video = FERTIG_ORDNER / f"{info_datei.stem}.mp4"
        if video.exists():
            info = json.loads(info_datei.read_text(encoding="utf-8"))
            clips.append((info_datei.stem, video, info))

    for name, log_name, praefix, stunden in PLATTFORMEN:
        log_datei = DATEN / log_name
        if not log_datei.exists() and name != "YouTube":
            continue
        log = lade_json(log_datei, {})
        max_tage = cfg.get(f"{praefix}_max_alter_tage", 3)
        pro_lauf = cfg.get(f"{praefix}_pro_lauf", 1)
        offen = [(i.get("twitch_aufrufe", 0), n, i) for n, v, i in clips
                 if n not in log and (time.time() - v.stat().st_mtime) / 86400 <= max_tage]
        offen.sort(key=lambda x: x[0], reverse=True)

        manuell = sum(1 for e in log.values() if e.get("manuell"))
        print(f"\n===== {name}: {len(offen)} Clips warten, {len(log) - manuell} schon hochgeladen"
              + (f", {manuell} fuer dich zum manuellen Hochladen" if manuell else "") + " =====")
        if not offen:
            print("  (nichts in der Warteschlange - um 10 Uhr kommen neue Clips)")
            continue
        zeiten = naechste_zeiten(stunden, -(-len(offen) // pro_lauf))
        for nr, (aufrufe, n, info) in enumerate(offen):
            zeit = zeiten[nr // pro_lauf].strftime("%a %H:%M") if nr // pro_lauf < len(zeiten) else "   ?   "
            print(f"  {zeit}  {aufrufe:>6} Aufrufe  {info.get('streamer', '?'):<15} {info.get('titel', n)[:60]}")
    print("\nHinweis: Um 10 Uhr kommen neue Clips dazu, dann kann sich die Reihenfolge aendern"
          " (die mit den meisten Twitch-Aufrufen gehen zuerst).")


if __name__ == "__main__":
    main()
