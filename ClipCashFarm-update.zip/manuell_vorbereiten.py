"""
Teilt die neuen Clips auf: Die besten (meiste Twitch-Aufrufe) laedt die YouTube-API automatisch hoch,
der Rest kommt in einen Ordner, damit du ihn selbst in YouTube Studio hochladen kannst.

Laeuft automatisch nach clip_fabrik.py (in clips_holen.bat), also gleich morgens um 10 Uhr:
  - Uebrig gebliebene Clips von frueheren Tagen kommen in den manuell-Ordner.
  - Von den heutigen Clips bleiben die besten fuer die API, der Rest kommt in den manuell-Ordner.
Ergebnis: clips/manuell/<Datum>/  mit den Videos und einer Datei "texte.txt" (Titel + Beschreibung zum Kopieren)

Einstellung in config.json: "youtube_api_pro_tag": 6
"""

import json
import shutil
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

# Emojis in Clip-Titeln sollen das Skript nicht abstuerzen lassen (Windows-Konsole/Log-Datei)
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


ORDNER = Path(__file__).resolve().parent
FERTIG_ORDNER = ORDNER / "clips" / "fertig"
MANUELL_ORDNER = ORDNER / "clips" / "manuell"
LOG_DATEI = ORDNER / "daten" / "youtube_hochgeladen.json"


def titel_mit_hashtags(info, max_hashtags=4, max_laenge=100):
    """Haengt so viele Hashtags an den Titel, wie in YouTubes 100 Zeichen passen."""
    titel = info["titel"].strip()
    for tag in info.get("tags", [])[:max_hashtags]:
        neu = f"{titel} #{tag}"
        if len(neu) > max_laenge:
            break
        titel = neu
    return titel[:max_laenge]


def lade_json(pfad, standard):
    if pfad.exists():
        return json.loads(pfad.read_text(encoding="utf-8"))
    return standard


def text_datei(ziel_ordner, name, info, cfg):
    (ziel_ordner / f"{name}.txt").write_text(
        f"{titel_mit_hashtags(info, cfg.get('youtube_titel_hashtags', 4))}\n\n{info['beschreibung']}\n",
        encoding="utf-8")


def fehlende_texte_erstellen(cfg):
    """Legt fuer alle Videos im manuell-Ordner eine .txt an, falls noch keine da ist (auch fuer alte Clips)."""
    neu = 0
    for video in MANUELL_ORDNER.glob("*/*.mp4"):
        if (video.parent / f"{video.stem}.txt").exists():
            continue
        info_datei = FERTIG_ORDNER / f"{video.stem}.json"
        if not info_datei.exists():
            continue
        text_datei(video.parent, video.stem, json.loads(info_datei.read_text(encoding="utf-8")), cfg)
        neu += 1
    if neu:
        print(f"{neu} Textdateien fuer aeltere Clips erstellt.")


def main():
    cfg = lade_json(ORDNER / "config.json", {})
    fehlende_texte_erstellen(cfg)
    if len(sys.argv) > 1 and sys.argv[1] == "texte":
        return
    api_pro_tag = cfg.get("youtube_api_pro_tag", 6)
    heute = datetime.now().date()
    max_tage = cfg.get("youtube_max_alter_tage", 3)
    log = lade_json(LOG_DATEI, {})

    offen = []
    for info_datei in FERTIG_ORDNER.glob("*.json"):
        name = info_datei.stem
        video = FERTIG_ORDNER / f"{name}.mp4"
        if name in log or not video.exists():
            continue
        if (time.time() - video.stat().st_mtime) / 86400 > max_tage:
            continue
        info = json.loads(info_datei.read_text(encoding="utf-8"))
        offen.append((info.get("twitch_aufrufe", 0), name, video, info))
    offen.sort(key=lambda x: x[0], reverse=True)

    # Alte Reste (nicht von heute) gehen immer in den manuell-Ordner
    alt = [c for c in offen if datetime.fromtimestamp(c[2].stat().st_mtime).date() != heute]
    neu = [c for c in offen if c not in alt]
    rest = alt + neu[api_pro_tag:]
    print(f"YouTube: {min(len(neu), api_pro_tag)} heutige Clips fuer die API, {len(rest)} zum manuellen Hochladen"
          f" (davon {len(alt)} Reste von frueheren Tagen).")
    if not rest:
        return

    ziel = MANUELL_ORDNER / datetime.now().strftime("%Y-%m-%d")
    ziel.mkdir(parents=True, exist_ok=True)
    with open(ziel / "texte.txt", "a", encoding="utf-8") as texte:
        for nr, (aufrufe, name, video, info) in enumerate(rest, 1):
            shutil.copy2(video, ziel / video.name)
            text_datei(ziel, name, info, cfg)  # eigene Textdatei pro Video
            texte.write(f"===== {video.name}  ({aufrufe} Twitch-Aufrufe) =====\n"
                        f"TITEL:\n{titel_mit_hashtags(info, cfg.get('youtube_titel_hashtags', 4))}\n\nBESCHREIBUNG:\n{info['beschreibung']}\n\n")
            # Damit die API diesen Clip nicht spaeter doch noch hochlaedt
            log[name] = {"manuell": True, "ordner": str(ziel),
                         "vorbereitet": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                         "twitch_aufrufe": aufrufe}
    LOG_DATEI.parent.mkdir(parents=True, exist_ok=True)
    LOG_DATEI.write_text(json.dumps(log, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Manuelle Clips liegen in {ziel}")


if __name__ == "__main__":
    main()
