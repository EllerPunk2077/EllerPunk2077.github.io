"""
Erstellt die .bat-Dateien fuer den Zeitplan in diesem Ordner.
Aufruf: python bat_dateien_erstellen.py
"""
from pathlib import Path

ORDNER = Path(__file__).resolve().parent

DATEIEN = {
    'clips_holen.bat': '@echo off\nrem Holt neue Clips und schneidet sie (laeuft 1x am Tag)\ncd /d C:\\ClipCashFarm\ncall venv\\Scripts\\activate.bat\nset PYTHONUTF8=1\npython clip_finder.py >> daten\\log.txt 2>&1\npython clip_fabrik.py >> daten\\log.txt 2>&1\npython manuell_vorbereiten.py >> daten\\log.txt 2>&1\n',
    'streamer_suchen.bat': '@echo off\nrem Merkt sich, wer gerade mit FitnaCraft live ist (laeuft stuendlich)\ncd /d C:\\ClipCashFarm\ncall venv\\Scripts\\activate.bat\nset PYTHONUTF8=1\npython clip_finder.py entdecken >> daten\\log.txt 2>&1\n',
    'youtube_hochladen.bat': '@echo off\nrem Laedt das naechste Short auf YouTube hoch (laeuft mehrmals am Tag)\ncd /d C:\\ClipCashFarm\ncall venv\\Scripts\\activate.bat\nset PYTHONUTF8=1\npython youtube_upload.py >> daten\\log.txt 2>&1\n',
    'zeitplan_einrichten.bat': '@echo off\nrem Richtet die automatischen Aufgaben in der Windows-Aufgabenplanung ein.\nrem Einmal per Doppelklick starten.\ncd /d C:\\ClipCashFarm\nif not exist daten mkdir daten\n\nschtasks /Create /F /TN "ClipCashFarm\\Streamer suchen" /TR "C:\\ClipCashFarm\\streamer_suchen.bat" /SC HOURLY /ST 00:15\nschtasks /Create /F /TN "ClipCashFarm\\Clips holen" /TR "C:\\ClipCashFarm\\clips_holen.bat" /SC DAILY /ST 10:00\nschtasks /Delete /F /TN "ClipCashFarm\\Tagesende" >nul 2>&1\n\nfor %%H in (12 14 16 18 20 22) do (\n  schtasks /Create /F /TN "ClipCashFarm\\YouTube %%H Uhr" /TR "C:\\ClipCashFarm\\youtube_hochladen.bat" /SC DAILY /ST %%H:00\n)\n\necho.\necho Fertig. Die Aufgaben findest du in der Aufgabenplanung unter "ClipCashFarm".\npause\n',
    'instagram_hochladen.bat': '@echo off\nrem Postet das naechste Reel auf Instagram\ncd /d C:\\ClipCashFarm\ncall venv\\Scripts\\activate.bat\nset PYTHONUTF8=1\npython instagram_upload.py >> daten\\log.txt 2>&1\n',
    'zeitplan_instagram.bat': '@echo off\nrem Richtet die Instagram-Uploads in der Aufgabenplanung ein (einmal per Doppelklick)\ncd /d C:\\ClipCashFarm\nfor %%H in (13 15 17 19 21) do (\n  schtasks /Create /F /TN "ClipCashFarm\\Instagram %%H Uhr" /TR "C:\\ClipCashFarm\\instagram_hochladen.bat" /SC DAILY /ST %%H:00\n)\necho.\necho Fertig. Instagram-Uploads um 13, 15, 17, 19 und 21 Uhr eingerichtet.\npause\n',
}

for name, inhalt in DATEIEN.items():
    (ORDNER / name).write_text(inhalt.replace("\n", "\r\n"), encoding="utf-8", newline="")
    print(f"Erstellt: {name}")
print("Fertig.")
