"""
Clip-Finder (Schritt 2)

Findet jeden Tag die meistgesehenen Twitch-Clips von FitnaCraft-Streamern
und laedt die besten herunter.

Ablauf:
  1. Entdecken: Wer ist gerade live mit "FitnaCraft" im Titel? -> streamer.json
  2. Clips holen: Clips der letzten X Stunden von allen bekannten Streamern
  3. Auswaehlen: nach Aufrufen sortieren, Doppelte raus, Top N
  4. Herunterladen nach clips/roh/ (Video + Infos als .json)

Aufruf:
  python clip_finder.py            -> entdecken + Clips herunterladen
  python clip_finder.py entdecken  -> nur Streamer-Liste aktualisieren
"""

import json
import re
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import requests
import yt_dlp

# Emojis in Clip-Titeln sollen das Skript nicht abstuerzen lassen (Windows-Konsole/Log-Datei)
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


ORDNER = Path(__file__).resolve().parent
CONFIG_DATEI = ORDNER / "config.json"
STREAMER_DATEI = ORDNER / "daten" / "streamer.json"
VERLAUF_DATEI = ORDNER / "daten" / "verlauf.json"
ROH_ORDNER = ORDNER / "clips" / "roh"

MINECRAFT_GAME_ID = "27471"
API = "https://api.twitch.tv/helix"


# ---------- Hilfsfunktionen ----------

def lade_json(pfad, standard):
    if pfad.exists():
        return json.loads(pfad.read_text(encoding="utf-8"))
    return standard


def speichere_json(pfad, daten):
    pfad.parent.mkdir(parents=True, exist_ok=True)
    pfad.write_text(json.dumps(daten, indent=2, ensure_ascii=False), encoding="utf-8")


def jetzt():
    return datetime.now(timezone.utc)


def rfc3339(zeit):
    return zeit.strftime("%Y-%m-%dT%H:%M:%SZ")


class Twitch:
    def __init__(self, client_id, client_secret):
        antwort = requests.post(
            "https://id.twitch.tv/oauth2/token",
            data={
                "client_id": client_id,
                "client_secret": client_secret,
                "grant_type": "client_credentials",
            },
            timeout=30,
        )
        if antwort.status_code != 200:
            sys.exit(f"Twitch-Anmeldung fehlgeschlagen: {antwort.text}\n"
                     "Pruefe client_id und client_secret in config.json.")
        token = antwort.json()["access_token"]
        self.kopf = {"Client-Id": client_id, "Authorization": f"Bearer {token}"}

    def hole(self, pfad, params):
        """Holt alle Seiten eines API-Aufrufs."""
        ergebnisse = []
        params = dict(params)
        while True:
            antwort = requests.get(f"{API}/{pfad}", headers=self.kopf, params=params, timeout=30)
            antwort.raise_for_status()
            daten = antwort.json()
            ergebnisse.extend(daten.get("data", []))
            cursor = daten.get("pagination", {}).get("cursor")
            if not cursor or not daten.get("data"):
                return ergebnisse
            params["after"] = cursor


# ---------- 1. Streamer entdecken ----------

def entdecken(twitch, cfg):
    streamer = lade_json(STREAMER_DATEI, {})
    muster = re.compile(cfg["titel_muster"], re.IGNORECASE)

    streams = [] if cfg.get("nur_immer_dabei") else twitch.hole("streams", {
        "game_id": MINECRAFT_GAME_ID,
        "language": "de",
        "type": "live",
        "first": 100,
    })
    neu = 0
    for s in streams:
        if not muster.search(s["title"]):
            continue
        eintrag = streamer.get(s["user_id"])
        if eintrag is None:
            neu += 1
            eintrag = {"login": s["user_login"], "name": s["user_name"], "max_zuschauer": 0}
        eintrag["zuletzt_gesehen"] = rfc3339(jetzt())
        eintrag["max_zuschauer"] = max(eintrag["max_zuschauer"], s["viewer_count"])
        streamer[s["user_id"]] = eintrag

    # Feste Streamer aus config.json ("immer_dabei") ergaenzen
    fehlende = [n.lower() for n in cfg.get("immer_dabei", [])
                if n.lower() not in {e["login"] for e in streamer.values()}]
    if fehlende:
        for u in twitch.hole("users", {"login": fehlende}):
            streamer[u["id"]] = {"login": u["login"], "name": u["display_name"],
                                 "max_zuschauer": 0, "zuletzt_gesehen": rfc3339(jetzt())}
            neu += 1

    speichere_json(STREAMER_DATEI, streamer)
    print(f"Streamer bekannt: {len(streamer)} (neu: {neu})")
    return streamer


# ---------- 2. + 3. Clips holen und auswaehlen ----------

def aktive_streamer(streamer, cfg):
    grenze = jetzt() - timedelta(days=cfg["streamer_aktiv_tage"])
    ausschliessen = {n.lower() for n in cfg.get("ausschliessen", [])}
    immer = {n.lower() for n in cfg.get("immer_dabei", [])}
    for uid, e in streamer.items():
        if e["login"] in ausschliessen:
            continue
        if cfg.get("nur_immer_dabei") and e["login"] not in immer:
            continue
        gesehen = datetime.strptime(e["zuletzt_gesehen"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
        if gesehen >= grenze or e["login"] in immer:
            yield uid, e


def clips_holen(twitch, streamer, cfg):
    bis = jetzt()
    von = bis - timedelta(hours=cfg["zeitraum_stunden"])
    alle = []
    for uid, e in aktive_streamer(streamer, cfg):
        clips = twitch.hole("clips", {
            "broadcaster_id": uid,
            "started_at": rfc3339(von),
            "ended_at": rfc3339(bis),
            "first": 100,
        })
        for c in clips:
            if cfg["nur_minecraft"] and c.get("game_id") != MINECRAFT_GAME_ID:
                continue
            if c["duration"] < cfg["min_sekunden"] or c["duration"] > cfg["max_sekunden"]:
                continue
            if c["view_count"] < cfg["min_aufrufe"]:
                continue
            c["broadcaster_login"] = e["login"]
            alle.append(c)
    print(f"Passende Clips gefunden: {len(alle)}")
    return alle


def gleicher_moment(a, b):
    """Zwei Clips zeigen wahrscheinlich dieselbe Szene (verschiedene Leute haben geclippt)."""
    if a["broadcaster_id"] != b["broadcaster_id"]:
        return False
    if a.get("video_id") and a.get("video_id") == b.get("video_id") \
            and a.get("vod_offset") is not None and b.get("vod_offset") is not None:
        return abs(a["vod_offset"] - b["vod_offset"]) < 60
    # Ohne VOD: Erstellungszeit vergleichen
    ta = datetime.strptime(a["created_at"], "%Y-%m-%dT%H:%M:%SZ")
    tb = datetime.strptime(b["created_at"], "%Y-%m-%dT%H:%M:%SZ")
    return abs((ta - tb).total_seconds()) < 60


def auswaehlen(clips, cfg):
    """Erst die festen Plaetze mit Clips der 'immer_dabei'-Streamer fuellen, dann den Rest."""
    immer = {n.lower() for n in cfg.get("immer_dabei", [])}
    feste_plaetze = min(cfg.get("plaetze_fuer_immer_dabei", 0), cfg["clips_pro_tag"])
    clips = sorted(clips, key=lambda c: c["view_count"], reverse=True)
    gewaehlt, pro_streamer = [], {}
    if feste_plaetze:
        feste = [c for c in clips if c["broadcaster_login"].lower() in immer]
        _fuellen(feste, feste_plaetze, gewaehlt, pro_streamer, cfg)
    _fuellen(clips, cfg["clips_pro_tag"], gewaehlt, pro_streamer, cfg)
    return gewaehlt


def _fuellen(clips, ziel, gewaehlt, pro_streamer, cfg):
    verlauf = lade_json(VERLAUF_DATEI, {})
    for c in clips:
        if len(gewaehlt) >= ziel:
            break
        if c in gewaehlt:
            continue
        if c["id"] in verlauf:
            continue
        if pro_streamer.get(c["broadcaster_id"], 0) >= cfg["max_pro_streamer"]:
            continue
        if any(gleicher_moment(c, g) for g in gewaehlt):
            continue
        gewaehlt.append(c)
        pro_streamer[c["broadcaster_id"]] = pro_streamer.get(c["broadcaster_id"], 0) + 1


# ---------- 4. Herunterladen ----------

def herunterladen(clips):
    verlauf = lade_json(VERLAUF_DATEI, {})
    ROH_ORDNER.mkdir(parents=True, exist_ok=True)
    for c in clips:
        name = f"{c['created_at'][:10]}_{c['broadcaster_name']}_{c['id']}"
        name = re.sub(r"[^\w\-]", "_", name)
        optionen = {"outtmpl": str(ROH_ORDNER / f"{name}.%(ext)s"), "quiet": True, "no_warnings": True}
        try:
            with yt_dlp.YoutubeDL(optionen) as ydl:
                ydl.download([c["url"]])
        except Exception as fehler:
            print(f"  FEHLER bei {c['url']}: {fehler}")
            continue
        speichere_json(ROH_ORDNER / f"{name}.json", c)
        verlauf[c["id"]] = {"datei": name, "geladen": rfc3339(jetzt()), "aufrufe": c["view_count"]}
        speichere_json(VERLAUF_DATEI, verlauf)
        print(f"  OK  {c['view_count']:>7} Aufrufe  {c['broadcaster_name']}: {c['title']}")
    speichere_json(VERLAUF_DATEI, verlauf)


# ---------- Start ----------

def main():
    if not CONFIG_DATEI.exists():
        sys.exit("config.json fehlt. Kopiere config.beispiel.json zu config.json und trag deine Twitch-Daten ein.")
    cfg = lade_json(CONFIG_DATEI, {})
    twitch = Twitch(cfg["twitch_client_id"], cfg["twitch_client_secret"])

    streamer = entdecken(twitch, cfg)
    if len(sys.argv) > 1 and sys.argv[1] == "entdecken":
        return
    if not streamer:
        print("Noch keine Streamer bekannt. Gerade ist niemand mit 'FitnaCraft' im Titel live.\n"
              "Trag ein paar Namen unter 'immer_dabei' in config.json ein oder versuch es abends nochmal.")
        return

    clips = clips_holen(twitch, streamer, cfg)
    gewaehlt = auswaehlen(clips, cfg)
    print(f"Lade {len(gewaehlt)} Clips herunter ...")
    herunterladen(gewaehlt)
    print("Fertig.")


if __name__ == "__main__":
    main()
