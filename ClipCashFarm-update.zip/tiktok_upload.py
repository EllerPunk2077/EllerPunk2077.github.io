"""
TikTok-Uploader (Schritt 5)

Laedt fertige Shorts aus clips/fertig/ zu TikTok. Zwei Modi (Einstellung "tiktok_modus"):
  "entwurf" (Standard): Das Video landet als Entwurf in deiner TikTok-App (Benachrichtigung).
                        Du tippst dort nur noch auf Posten. Der passende Text steht in
                        daten/tiktok_texte.txt zum Kopieren. Wird von TikTok am ehesten genehmigt.
  "direkt":             Das Video wird sofort gepostet (braucht die TikTok-Pruefung fuer Direct Post).

Aufruf:
  python tiktok_upload.py anmelden   -> einmalig bei TikTok anmelden
  python tiktok_upload.py            -> naechste(s) Video(s) hochladen
"""

import json
import math
import secrets
import sys
import time
import webbrowser
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode

import requests

# Emojis in Clip-Titeln sollen das Skript nicht abstuerzen lassen (Windows-Konsole/Log-Datei)
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


ORDNER = Path(__file__).resolve().parent
CONFIG_DATEI = ORDNER / "config.json"
TOKEN_DATEI = ORDNER / "daten" / "tiktok_token.json"
FERTIG_ORDNER = ORDNER / "clips" / "fertig"
LOG_DATEI = ORDNER / "daten" / "tiktok_hochgeladen.json"

REDIRECT_URI = "https://ellerpunk2077.github.io/tiktok.html"
TEXTE_DATEI = ORDNER / "daten" / "tiktok_texte.txt"
API = "https://open.tiktokapis.com/v2"

STANDARD = {
    "tiktok_modus": "entwurf",             # "entwurf" oder "direkt"
    "tiktok_pro_lauf": 1,
    "tiktok_privatsphaere": "SELF_ONLY",   # nach der TikTok-Pruefung: PUBLIC_TO_EVERYONE
    "tiktok_max_alter_tage": 3,
}

MAX_EINZELSTUECK = 64 * 1024 * 1024
STUECK = 10 * 1024 * 1024


def lade_json(pfad, standard):
    if pfad.exists():
        return json.loads(pfad.read_text(encoding="utf-8"))
    return standard


def speichere_json(pfad, daten):
    pfad.parent.mkdir(parents=True, exist_ok=True)
    pfad.write_text(json.dumps(daten, indent=2, ensure_ascii=False), encoding="utf-8")


def lade_config():
    roh = lade_json(CONFIG_DATEI, {})
    cfg = dict(STANDARD)
    cfg.update({k: v for k, v in roh.items() if k.startswith("tiktok_")})
    if not cfg.get("tiktok_client_key") or not cfg.get("tiktok_client_secret"):
        sys.exit("tiktok_client_key und tiktok_client_secret fehlen in config.json.")
    return cfg


# ---------- Anmeldung ----------

def token_speichern(daten):
    jetzt = time.time()
    daten["access_ablauf"] = jetzt + int(daten.get("expires_in", 0)) - 120
    daten["refresh_ablauf"] = jetzt + int(daten.get("refresh_expires_in", 0)) - 3600
    speichere_json(TOKEN_DATEI, daten)
    return daten


def token_anfrage(cfg, extra):
    antwort = requests.post(
        f"{API}/oauth/token/",
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        data={"client_key": cfg["tiktok_client_key"], "client_secret": cfg["tiktok_client_secret"], **extra},
        timeout=30,
    )
    daten = antwort.json()
    if "access_token" not in daten:
        sys.exit(f"TikTok-Anmeldung fehlgeschlagen: {daten}")
    return token_speichern(daten)


def anmelden(cfg):
    state = secrets.token_urlsafe(16)
    url = "https://www.tiktok.com/v2/auth/authorize/?" + urlencode({
        "client_key": cfg["tiktok_client_key"],
        "scope": "user.info.basic,video.publish" if cfg["tiktok_modus"] == "direkt" else "user.info.basic,video.upload",
        "response_type": "code",
        "redirect_uri": REDIRECT_URI,
        "state": state,
    })
    print("Der Browser oeffnet sich. Melde dich bei TikTok an und erlaube den Zugriff.")
    print("Danach zeigt die Seite einen Code an. Kopiere ihn und fuege ihn hier ein.\n")
    print(url + "\n")
    webbrowser.open(url)
    code = input("Code: ").strip()
    token_anfrage(cfg, {"code": code, "grant_type": "authorization_code", "redirect_uri": REDIRECT_URI})
    print("TikTok-Anmeldung klappt.")


def access_token(cfg):
    token = lade_json(TOKEN_DATEI, None)
    if not token:
        sys.exit("Noch nicht bei TikTok angemeldet. Starte: python tiktok_upload.py anmelden")
    if time.time() < token["access_ablauf"]:
        return token["access_token"]
    if time.time() > token["refresh_ablauf"]:
        sys.exit("TikTok-Anmeldung abgelaufen. Starte: python tiktok_upload.py anmelden")
    token = token_anfrage(cfg, {"grant_type": "refresh_token", "refresh_token": token["refresh_token"]})
    return token["access_token"]


# ---------- Upload ----------

def api(token, pfad, body):
    antwort = requests.post(
        f"{API}/{pfad}",
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json; charset=UTF-8"},
        json=body,
        timeout=60,
    )
    daten = antwort.json()
    fehler = daten.get("error", {})
    if fehler.get("code") not in (None, "ok"):
        raise RuntimeError(f"{fehler.get('code')}: {fehler.get('message')}")
    return daten.get("data", {})


def stuecke_planen(groesse):
    if groesse <= MAX_EINZELSTUECK:
        return groesse, 1
    return STUECK, groesse // STUECK  # letztes Stueck nimmt den Rest mit


def datei_senden(upload_url, video, groesse, stueck, anzahl):
    with open(video, "rb") as f:
        for i in range(anzahl):
            start = i * stueck
            ende = groesse - 1 if i == anzahl - 1 else start + stueck - 1
            f.seek(start)
            daten = f.read(ende - start + 1)
            antwort = requests.put(upload_url, data=daten, timeout=300, headers={
                "Content-Type": "video/mp4",
                "Content-Range": f"bytes {start}-{ende}/{groesse}",
            })
            if antwort.status_code not in (200, 201, 206):
                raise RuntimeError(f"Upload-Teil {i + 1} fehlgeschlagen: {antwort.status_code} {antwort.text[:300]}")


def auf_status_warten(token, publish_id, ziel):
    for _ in range(40):
        time.sleep(6)
        status = api(token, "post/publish/status/fetch/", {"publish_id": publish_id})
        s = status.get("status")
        if s == ziel:
            return
        if s == "FAILED":
            raise RuntimeError(f"TikTok meldet Fehler: {status.get('fail_reason')}")
    print("  TikTok verarbeitet noch, das Video erscheint gleich.")


def als_entwurf(token, video, info):
    groesse = video.stat().st_size
    stueck, anzahl = stuecke_planen(groesse)
    init = api(token, "post/publish/inbox/video/init/", {
        "source_info": {"source": "FILE_UPLOAD", "video_size": groesse,
                        "chunk_size": stueck, "total_chunk_count": anzahl},
    })
    datei_senden(init["upload_url"], video, groesse, stueck, anzahl)
    auf_status_warten(token, init["publish_id"], "SEND_TO_USER_INBOX")
    # Text zum Kopieren ablegen (bei Entwuerfen kann TikTok keinen Text mitschicken)
    TEXTE_DATEI.parent.mkdir(parents=True, exist_ok=True)
    with open(TEXTE_DATEI, "a", encoding="utf-8") as f:
        f.write(f"===== {datetime.now():%d.%m. %H:%M} | {info['streamer']} =====\n"
                f"{info['titel']}\n\n{info.get('hashtags', '')}\n\n")
    return init["publish_id"]


def hochladen(token, video, info, cfg):
    if cfg["tiktok_modus"] != "direkt":
        return als_entwurf(token, video, info)
    creator = api(token, "post/publish/creator_info/query/", {})
    optionen = creator.get("privacy_level_options", [])
    privat = cfg["tiktok_privatsphaere"]
    if optionen and privat not in optionen:
        ersatz = "SELF_ONLY" if "SELF_ONLY" in optionen else optionen[-1]
        print(f"  Hinweis: '{privat}' ist noch nicht erlaubt, nehme '{ersatz}'.")
        privat = ersatz

    groesse = video.stat().st_size
    stueck, anzahl = stuecke_planen(groesse)
    titel = f"{info['titel']}\n\n{info.get('hashtags', '')}"[:2200]
    init = api(token, "post/publish/video/init/", {
        "post_info": {
            "title": titel,
            "privacy_level": privat,
            "disable_duet": False,
            "disable_comment": False,
            "disable_stitch": False,
            "video_cover_timestamp_ms": 1000,
        },
        "source_info": {
            "source": "FILE_UPLOAD",
            "video_size": groesse,
            "chunk_size": stueck,
            "total_chunk_count": anzahl,
        },
    })
    datei_senden(init["upload_url"], video, groesse, stueck, anzahl)
    auf_status_warten(token, init["publish_id"], "PUBLISH_COMPLETE")
    return init["publish_id"]


def naechste_videos(cfg, log):
    jetzt = time.time()
    kandidaten = []
    for info_datei in FERTIG_ORDNER.glob("*.json"):
        name = info_datei.stem
        video = FERTIG_ORDNER / f"{name}.mp4"
        if name in log or not video.exists():
            continue
        if (jetzt - video.stat().st_mtime) / 86400 > cfg["tiktok_max_alter_tage"]:
            continue
        info = json.loads(info_datei.read_text(encoding="utf-8"))
        kandidaten.append((info.get("twitch_aufrufe", 0), name, video, info))
    kandidaten.sort(reverse=True)
    return kandidaten[: cfg["tiktok_pro_lauf"]]


def main():
    cfg = lade_config()
    if len(sys.argv) > 1 and sys.argv[1] == "anmelden":
        anmelden(cfg)
        return

    token = access_token(cfg)
    log = lade_json(LOG_DATEI, {})
    videos = naechste_videos(cfg, log)
    if not videos:
        print("Keine neuen Videos fuer TikTok in clips/fertig/.")
        return
    for aufrufe, name, video, info in videos:
        print(f"TikTok: {info['titel']}")
        try:
            publish_id = hochladen(token, video, info, cfg)
        except Exception as fehler:
            print(f"  FEHLER: {fehler}")
            continue
        log[name] = {"publish_id": publish_id, "twitch_aufrufe": aufrufe,
                     "hochgeladen": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}
        speichere_json(LOG_DATEI, log)
        print("  OK" + (" - liegt als Entwurf in deiner TikTok-App" if cfg["tiktok_modus"] != "direkt" else ""))


if __name__ == "__main__":
    main()
