"""
Instagram-Reels-Uploader (Schritt 6)

Laedt fertige Shorts aus clips/fertig/ als Reels auf deinen Instagram-Account.
Instagram holt das Video selbst von einem oeffentlichen Link. Dafuer wird jeder Clip
kurz in einen Supabase-Speicher gelegt und nach dem Posten wieder geloescht.

Aufruf:
  python instagram_upload.py testen   -> prueft Token und Speicher
  python instagram_upload.py          -> naechste(s) Reel(s) posten
"""

import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import requests

# Emojis in Clip-Titeln sollen das Skript nicht abstuerzen lassen (Windows-Konsole/Log-Datei)
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


ORDNER = Path(__file__).resolve().parent
CONFIG_DATEI = ORDNER / "config.json"
TOKEN_DATEI = ORDNER / "daten" / "instagram_token.json"
FERTIG_ORDNER = ORDNER / "clips" / "fertig"
LOG_DATEI = ORDNER / "daten" / "instagram_hochgeladen.json"

GRAPH = "https://graph.instagram.com/v24.0"

STANDARD = {
    "instagram_pro_lauf": 1,
    "instagram_max_alter_tage": 3,
    "supabase_bucket": "clips",
}


def lade_json(pfad, standard):
    if pfad.exists():
        return json.loads(pfad.read_text(encoding="utf-8"))
    return standard


def speichere_json(pfad, daten):
    pfad.parent.mkdir(parents=True, exist_ok=True)
    pfad.write_text(json.dumps(daten, indent=2, ensure_ascii=False), encoding="utf-8")


def lade_config():
    roh = lade_json(CONFIG_DATEI, {})
    cfg = dict(STANDARD)
    cfg.update({k: v for k, v in roh.items() if k.startswith(("instagram_", "supabase_"))})
    for feld in ("instagram_token", "supabase_url", "supabase_key"):
        if not cfg.get(feld) or cfg[feld].startswith("HIER_"):
            sys.exit(f"'{feld}' fehlt in config.json.")
    cfg["supabase_url"] = cfg["supabase_url"].rstrip("/")
    return cfg


# ---------- Token (haelt 60 Tage, wird automatisch verlaengert) ----------

def token_holen(cfg):
    gespeichert = lade_json(TOKEN_DATEI, None)
    # Neuer Token in config.json? Dann den nehmen.
    if not gespeichert or gespeichert.get("aus_config") != cfg["instagram_token"]:
        gespeichert = {"token": cfg["instagram_token"], "aus_config": cfg["instagram_token"],
                       "erneuert": time.time()}
        speichere_json(TOKEN_DATEI, gespeichert)
    # Einmal pro Woche verlaengern (geht erst, wenn der Token mind. 24 h alt ist)
    if time.time() - gespeichert["erneuert"] > 7 * 86400:
        antwort = requests.get("https://graph.instagram.com/refresh_access_token",
                               params={"grant_type": "ig_refresh_token", "access_token": gespeichert["token"]},
                               timeout=30).json()
        if "access_token" in antwort:
            gespeichert["token"] = antwort["access_token"]
            gespeichert["erneuert"] = time.time()
            speichere_json(TOKEN_DATEI, gespeichert)
            print("Instagram-Token verlaengert.")
        else:
            print(f"Token-Verlaengerung fehlgeschlagen: {antwort}")
    return gespeichert["token"]


def ig(methode, pfad, token, **params):
    params["access_token"] = token
    antwort = requests.request(methode, f"{GRAPH}/{pfad}", params=params, timeout=60)
    daten = antwort.json()
    if "error" in daten:
        raise RuntimeError(daten["error"].get("message", daten["error"]))
    return daten


# ---------- Supabase-Speicher ----------

def sb_kopf(cfg, extra=None):
    kopf = {"Authorization": f"Bearer {cfg['supabase_key']}", "apikey": cfg["supabase_key"]}
    kopf.update(extra or {})
    return kopf


def speicher_hoch(cfg, video):
    ziel = f"{cfg['supabase_url']}/storage/v1/object/{cfg['supabase_bucket']}/{video.name}"
    with open(video, "rb") as f:
        antwort = requests.post(ziel, data=f, timeout=300,
                                headers=sb_kopf(cfg, {"Content-Type": "video/mp4", "x-upsert": "true"}))
    if antwort.status_code not in (200, 201):
        raise RuntimeError(f"Speicher-Upload fehlgeschlagen: {antwort.status_code} {antwort.text[:300]}")
    return f"{cfg['supabase_url']}/storage/v1/object/public/{cfg['supabase_bucket']}/{video.name}"


def speicher_loeschen(cfg, video):
    requests.delete(f"{cfg['supabase_url']}/storage/v1/object/{cfg['supabase_bucket']}",
                    json={"prefixes": [video.name]}, headers=sb_kopf(cfg), timeout=30)


# ---------- Reel posten ----------

def reel_posten(cfg, token, user_id, video, info):
    link = speicher_hoch(cfg, video)
    try:
        caption = f"{info['titel']}\n\n{info.get('beschreibung', '')}"[:2200]
        container = ig("POST", f"{user_id}/media", token, media_type="REELS", video_url=link,
                       caption=caption, share_to_feed="true")["id"]
        for _ in range(30):
            time.sleep(10)
            status = ig("GET", container, token, fields="status_code,status").get("status_code")
            if status == "FINISHED":
                break
            if status in ("ERROR", "EXPIRED"):
                raise RuntimeError(f"Instagram konnte das Video nicht verarbeiten ({status}).")
        else:
            raise RuntimeError("Instagram braucht zu lange fuer die Verarbeitung.")
        media_id = ig("POST", f"{user_id}/media_publish", token, creation_id=container)["id"]
        try:
            return media_id, ig("GET", media_id, token, fields="permalink").get("permalink", "")
        except Exception:
            return media_id, ""
    finally:
        speicher_loeschen(cfg, video)


def naechste_videos(cfg, log):
    jetzt = time.time()
    kandidaten = []
    for info_datei in FERTIG_ORDNER.glob("*.json"):
        name = info_datei.stem
        video = FERTIG_ORDNER / f"{name}.mp4"
        if name in log or not video.exists():
            continue
        if (jetzt - video.stat().st_mtime) / 86400 > cfg["instagram_max_alter_tage"]:
            continue
        info = json.loads(info_datei.read_text(encoding="utf-8"))
        kandidaten.append((info.get("twitch_aufrufe", 0), name, video, info))
    kandidaten.sort(reverse=True)
    return kandidaten[: cfg["instagram_pro_lauf"]]


def main():
    cfg = lade_config()
    token = token_holen(cfg)
    ich = ig("GET", "me", token, fields="user_id,username")
    user_id = ich["user_id"]

    if len(sys.argv) > 1 and sys.argv[1] == "testen":
        print(f"Instagram-Token klappt: @{ich.get('username')}")
        test = ORDNER / "daten" / "speichertest.mp4"
        test.parent.mkdir(parents=True, exist_ok=True)
        test.write_bytes(b"test")
        link = speicher_hoch(cfg, test)
        ok = requests.get(link, timeout=30).status_code == 200
        speicher_loeschen(cfg, test)
        test.unlink()
        print("Speicher klappt." if ok else "Speicher-Link nicht oeffentlich: Ist der Bucket auf 'Public' gestellt?")
        return

    log = lade_json(LOG_DATEI, {})
    videos = naechste_videos(cfg, log)
    if not videos:
        print("Keine neuen Videos fuer Instagram in clips/fertig/.")
        return
    for aufrufe, name, video, info in videos:
        print(f"Instagram: {info['titel']}")
        try:
            media_id, link = reel_posten(cfg, token, user_id, video, info)
        except Exception as fehler:
            print(f"  FEHLER: {fehler}")
            continue
        log[name] = {"media_id": media_id, "link": link, "twitch_aufrufe": aufrufe,
                     "hochgeladen": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}
        speichere_json(LOG_DATEI, log)
        print(f"  OK {link}")


if __name__ == "__main__":
    main()
