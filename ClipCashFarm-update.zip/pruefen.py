"""
Prueft, ob alle Skripte, Einstellungen und Zeitplan-Aufgaben auf dem neuesten Stand sind.

Aufruf: python pruefen.py
"""

import hashlib
import json
import subprocess
from pathlib import Path

ORDNER = Path(__file__).resolve().parent

# Stand der Skripte (wird bei jeder neuen Version von pruefen.py aktualisiert)
ERWARTET = {
    "clip_finder.py": "84b6f0aea511",
    "clip_fabrik.py": "5928df4f1899",
    "manuell_vorbereiten.py": "d263a14985f5",
    "youtube_upload.py": "240ec9194e78",
    "warteschlange.py": "a48e1d7c9356",
    "bat_dateien_erstellen.py": "e97499865943",
    "instagram_upload.py": "797d765174ac",
    "tiktok_upload.py": "8912527ae8f2",
    "requirements.txt": "a6c701ae478b"
}

CONFIG_FELDER = {
    "titel_muster": "fitna\\s*craft",
    "youtube_api_pro_tag": 6,
    "youtube_titel_hashtags": 4,
}
FABRIK_FELDER = ["projekt_name", "standard_hashtags", "ohne_untertitel"]

AUFGABEN = ["Streamer suchen", "Clips holen"] + [f"YouTube {h} Uhr" for h in (12, 14, 16, 18, 20, 22)]


def ok(text):
    print(f"  [OK]     {text}")


def fehler(text):
    print(f"  [FEHLT]  {text}")
    return 1


def main():
    probleme = 0

    print("\n1. Skripte")
    for datei, soll in ERWARTET.items():
        pfad = ORDNER / datei
        if not pfad.exists():
            if datei in ("instagram_upload.py", "tiktok_upload.py"):
                print(f"  [--]     {datei} (noch nicht noetig)")
                continue
            probleme += fehler(f"{datei} fehlt")
            continue
        ist = hashlib.sha256(pfad.read_bytes().replace(b"\r\n", b"\n")).hexdigest()[:12]
        if ist == soll:
            ok(datei)
        else:
            probleme += fehler(f"{datei} ist eine alte Version -> neu herunterladen")

    print("\n2. .bat-Dateien")
    bat = ORDNER / "clips_holen.bat"
    if bat.exists() and all(t in bat.read_text(encoding="utf-8", errors="ignore") for t in ("manuell_vorbereiten.py", "PYTHONUTF8")):
        ok("clips_holen.bat startet manuell_vorbereiten.py")
    else:
        probleme += fehler("clips_holen.bat ist alt -> python bat_dateien_erstellen.py ausfuehren")

    print("\n3. Einstellungen (config.json)")
    try:
        cfg = json.loads((ORDNER / "config.json").read_text(encoding="utf-8"))
    except Exception as e:
        cfg = {}
        probleme += fehler(f"config.json kann nicht gelesen werden: {e}")
    for feld, beispiel in CONFIG_FELDER.items():
        if feld in cfg:
            ok(f"{feld} = {cfg[feld]}")
        else:
            print(f"  [INFO]   {feld} fehlt, Standard wird benutzt ({beispiel})")
    for feld in FABRIK_FELDER:
        if feld in cfg.get("fabrik", {}):
            ok(f"fabrik.{feld} = {cfg['fabrik'][feld]}")
        else:
            print(f"  [INFO]   fabrik.{feld} fehlt, Standard wird benutzt")
    if "fitna" not in str(cfg.get("titel_muster", "")).lower():
        probleme += fehler("titel_muster sucht nicht nach FitnaCraft")

    print("\n4. Zeitplan (Windows-Aufgabenplanung)")
    try:
        ausgabe = subprocess.run(["schtasks", "/Query", "/FO", "CSV", "/NH"], capture_output=True,
                                 text=True, errors="ignore").stdout
    except FileNotFoundError:
        ausgabe = ""
    for aufgabe in AUFGABEN:
        if f"\\ClipCashFarm\\{aufgabe}" in ausgabe:
            ok(aufgabe)
        else:
            probleme += fehler(f"Aufgabe '{aufgabe}' -> zeitplan_einrichten.bat per Doppelklick starten")
    for alt in ("Tagesende", "YouTube 00 Uhr", "YouTube 04 Uhr", "YouTube 08 Uhr"):
        if f"\\ClipCashFarm\\{alt}" in ausgabe:
            probleme += fehler(f"Alte Aufgabe '{alt}' noch da -> in der Aufgabenplanung loeschen")

    print("\n" + ("Alles auf dem neuesten Stand!" if probleme == 0 else f"{probleme} Punkt(e) zu erledigen, siehe [FEHLT]."))


if __name__ == "__main__":
    main()
