"""
Clip-Fabrik (Schritt 3)

Macht aus jedem heruntergeladenen Twitch-Clip ein fertiges Short:
  - Hochformat 1080x1920: unscharfer Hintergrund, Clip gross in der Mitte
  - Oben: Titel-Text, darunter Credit an den Streamer
  - Untertitel Wort fuer Wort (Whisper, laeuft lokal und kostenlos)
  - Titel, Beschreibung und Hashtags fuer den Upload

Eingang:  clips/roh/      (vom Clip-Finder)
Ausgang:  clips/fertig/   (Video .mp4 + Upload-Infos .json)

Aufruf:   python clip_fabrik.py
"""

import json
import re
import subprocess
import sys
from pathlib import Path

# Emojis in Clip-Titeln sollen das Skript nicht abstuerzen lassen (Windows-Konsole/Log-Datei)
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


ORDNER = Path(__file__).resolve().parent
CONFIG_DATEI = ORDNER / "config.json"
ROH_ORDNER = ORDNER / "clips" / "roh"
FERTIG_ORDNER = ORDNER / "clips" / "fertig"
ARBEIT_ORDNER = ORDNER / "clips" / "arbeit"

STANDARD = {
    "untertitel": True,             # false = nie eigene Untertitel
    "ohne_untertitel": [],          # Streamer, die schon eigene Untertitel im Stream haben, z. B. ["trymacs"]
    "whisper_modell": "small",      # tiny, base, small, medium (groesser = genauer, langsamer)
    "whisper_geraet": "cpu",        # "cpu" oder "cuda" (Grafikkarte, braucht extra Treiber)
    "encoder": "h264_nvenc",        # "h264_nvenc" (Grafikkarte) oder "libx264" (Prozessor)
    "vordergrund_zoom": 1.25,       # 1.0 = ganzes Bild, groesser = Clip naeher rangezoomt
    "woerter_pro_untertitel": 3,
    "projekt_name": "FitnaCraft",
    "standard_hashtags": ["fitnacraft", "minecraft", "twitch", "shorts", "deutsch"],
}

BREITE, HOEHE = 1080, 1920


def lade_config():
    cfg = dict(STANDARD)
    if CONFIG_DATEI.exists():
        cfg.update(json.loads(CONFIG_DATEI.read_text(encoding="utf-8")).get("fabrik", {}))
    return cfg


# ---------- Untertitel ----------

_whisper = None


def audio_laden(video):
    """Holt die Tonspur per FFmpeg als 16-kHz-Mono (das Format, das Whisper braucht)."""
    import numpy as np
    ergebnis = subprocess.run(
        ["ffmpeg", "-loglevel", "error", "-i", str(video), "-vn", "-ac", "1", "-ar", "16000", "-f", "s16le", "-"],
        capture_output=True)
    if ergebnis.returncode != 0:
        raise RuntimeError(ergebnis.stderr.decode(errors="ignore").strip()[-500:])
    return np.frombuffer(ergebnis.stdout, np.int16).astype(np.float32) / 32768.0


def transkribieren(video, cfg):
    """Gibt eine Liste von Woertern mit Start- und Endzeit zurueck."""
    global _whisper
    if _whisper is None:
        from faster_whisper import WhisperModel
        print(f"  Lade Whisper-Modell '{cfg['whisper_modell']}' (beim ersten Mal dauert das) ...")
        try:
            _whisper = WhisperModel(cfg["whisper_modell"], device=cfg["whisper_geraet"], compute_type="int8")
        except Exception as fehler:
            if cfg["whisper_geraet"] == "cpu":
                raise
            print(f"  Grafikkarte fuer Whisper nicht nutzbar ({fehler}), nehme CPU.")
            _whisper = WhisperModel(cfg["whisper_modell"], device="cpu", compute_type="int8")
    segmente, _ = _whisper.transcribe(audio_laden(video), language="de", word_timestamps=True, vad_filter=True)
    woerter = []
    for seg in segmente:
        for w in seg.words or []:
            text = w.word.strip()
            if text:
                woerter.append((w.start, w.end, text))
    return woerter


def ass_zeit(sek):
    h = int(sek // 3600)
    m = int(sek % 3600 // 60)
    s = sek % 60
    return f"{h}:{m:02d}:{s:05.2f}"


def ass_text(text):
    return text.replace("\\", "").replace("{", "(").replace("}", ")").replace("\n", " ")


def umbrechen(text, max_zeichen=22):
    """Bricht langen Titeltext in mehrere Zeilen um."""
    zeilen, aktuell = [], ""
    for wort in text.split():
        if aktuell and len(aktuell) + 1 + len(wort) > max_zeichen:
            zeilen.append(aktuell)
            aktuell = wort
        else:
            aktuell = f"{aktuell} {wort}".strip()
    if aktuell:
        zeilen.append(aktuell)
    return r"\N".join(zeilen[:3])


def schreibe_ass(pfad, woerter, titel, streamer, dauer, cfg):
    kopf = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {BREITE}
PlayResY: {HOEHE}
WrapStyle: 0

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Untertitel,Arial Black,78,&H00FFFFFF,&H00FFFFFF,&H00000000,&H80000000,1,0,0,0,100,100,0,0,1,6,2,5,60,60,0,1
Style: Titel,Arial Black,64,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,1,0,0,0,100,100,0,0,1,5,0,8,60,60,230,1
Style: Credit,Arial,44,&H0000D7FF,&H0000D7FF,&H00000000,&H00000000,1,0,0,0,100,100,0,0,1,3,0,8,60,60,520,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    zeilen = [kopf]
    ende = ass_zeit(dauer + 1)
    zeilen.append(f"Dialogue: 0,0:00:00.00,{ende},Titel,,0,0,0,,{umbrechen(ass_text(titel).upper())}\n")
    zeilen.append(f"Dialogue: 0,0:00:00.00,{ende},Credit,,0,0,0,,twitch.tv/{ass_text(streamer)}\n")

    # Untertitel: immer ein paar Woerter zusammen, in der Mitte unter dem Clip
    n = cfg["woerter_pro_untertitel"]
    for i in range(0, len(woerter), n):
        gruppe = woerter[i:i + n]
        start = gruppe[0][0]
        stop = woerter[i + n][0] if i + n < len(woerter) else gruppe[-1][1] + 0.3
        text = ass_text(" ".join(w[2] for w in gruppe)).upper()
        # Position: unteres Drittel (y = 1450)
        zeilen.append(f"Dialogue: 1,{ass_zeit(start)},{ass_zeit(stop)},Untertitel,,0,0,0,,{{\\pos(540,1450)}}{text}\n")
    pfad.write_text("".join(zeilen), encoding="utf-8")


# ---------- Video bauen ----------

def video_bauen(roh, ass_datei, ziel, cfg):
    zoom = cfg["vordergrund_zoom"]
    vb = int(BREITE * zoom) // 2 * 2
    filter_kette = (
        f"[0:v]scale={BREITE}:{HOEHE}:force_original_aspect_ratio=increase,"
        f"crop={BREITE}:{HOEHE},boxblur=25:5,eq=brightness=-0.15[bg];"
        f"[0:v]scale={vb}:-2,crop={BREITE}:ih[fg];"
        f"[bg][fg]overlay=(W-w)/2:(H-h)/2,ass={ass_datei.name}[v]"
    )

    def befehl(encoder):
        qualitaet = ["-cq", "23", "-preset", "p5"] if encoder == "h264_nvenc" else ["-crf", "21", "-preset", "medium"]
        return ["ffmpeg", "-y", "-loglevel", "error", "-i", str(roh),
                "-filter_complex", filter_kette, "-map", "[v]", "-map", "0:a?",
                "-c:v", encoder, *qualitaet, "-pix_fmt", "yuv420p", "-r", "30",
                "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", str(ziel)]

    # ffmpeg im Arbeitsordner starten, damit der Untertitel-Pfad ohne "C:" auskommt
    ergebnis = subprocess.run(befehl(cfg["encoder"]), cwd=ass_datei.parent, capture_output=True, text=True)
    if ergebnis.returncode != 0 and cfg["encoder"] != "libx264":
        print("  Grafikkarten-Encoder klappt nicht, nehme Prozessor (langsamer) ...")
        ergebnis = subprocess.run(befehl("libx264"), cwd=ass_datei.parent, capture_output=True, text=True)
    if ergebnis.returncode != 0:
        raise RuntimeError(ergebnis.stderr.strip()[-800:])


# ---------- Upload-Infos ----------

def upload_infos(info, cfg):
    streamer = info["broadcaster_name"]
    titel = info["title"].strip()
    if len(titel) < 4:
        titel = f"{streamer} in {cfg['projekt_name']}"
    tags = [streamer.lower()] + cfg["standard_hashtags"]
    tags = list(dict.fromkeys(re.sub(r"\W", "", t).lower() for t in tags if t))
    hashtags = " ".join(f"#{t}" for t in tags)
    return {
        "titel": f"{titel} | {streamer}"[:95],
        "beschreibung": (f"{titel}\n\nClip aus dem Stream von {streamer}: https://twitch.tv/{info.get('broadcaster_login', streamer.lower())}\n"
                         f"Original-Clip: {info['url']}\n\n{hashtags}"),
        "tags": tags,
        "hashtags": hashtags,
        "streamer": streamer,
        "twitch_aufrufe": info["view_count"],
        "twitch_clip_id": info["id"],
    }


# ---------- Start ----------

def main():
    cfg = lade_config()
    FERTIG_ORDNER.mkdir(parents=True, exist_ok=True)
    ARBEIT_ORDNER.mkdir(parents=True, exist_ok=True)

    offen = []
    for info_datei in sorted(ROH_ORDNER.glob("*.json")):
        name = info_datei.stem
        if (FERTIG_ORDNER / f"{name}.mp4").exists():
            continue
        videos = [p for p in ROH_ORDNER.glob(f"{name}.*") if p.suffix != ".json"]
        if videos:
            offen.append((name, videos[0], info_datei))

    if not offen:
        print("Keine neuen Clips in clips/roh/. Erst clip_finder.py laufen lassen.")
        return
    print(f"{len(offen)} Clips zu bearbeiten.")

    for name, roh, info_datei in offen:
        info = json.loads(info_datei.read_text(encoding="utf-8"))
        print(f"- {info['broadcaster_name']}: {info['title']}")
        try:
            login = info.get("broadcaster_login", info["broadcaster_name"]).lower()
            ohne = {n.lower() for n in cfg["ohne_untertitel"]}
            woerter = transkribieren(roh, cfg) if cfg["untertitel"] and login not in ohne else []
            ass_datei = ARBEIT_ORDNER / f"{name}.ass"
            schreibe_ass(ass_datei, woerter, info["title"], info.get("broadcaster_login", info["broadcaster_name"]),
                         float(info.get("duration", 60)), cfg)
            ziel = FERTIG_ORDNER / f"{name}.mp4"
            video_bauen(roh, ass_datei, ziel, cfg)
            daten = upload_infos(info, cfg)
            (FERTIG_ORDNER / f"{name}.json").write_text(json.dumps(daten, indent=2, ensure_ascii=False), encoding="utf-8")
            print(f"  OK ({len(woerter)} Woerter Untertitel)")
        except Exception as fehler:
            print(f"  FEHLER: {fehler}")
    print("Fertig. Die Shorts liegen in clips/fertig/")


if __name__ == "__main__":
    main()
